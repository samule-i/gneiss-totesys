def tmp():
  return True

if __name__ == '__main__':
  tmp()