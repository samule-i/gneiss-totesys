def lambda_handler(event, context):
    '''Should connect to a PGSQL database
    collect data from connection
    update an S3 bucket with files created from data'''
    return True
