def lambda_handler(event, context):
    print('test function')